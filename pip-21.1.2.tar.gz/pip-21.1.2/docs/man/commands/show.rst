:orphan:

========
pip-show
========

Description
***********

.. pip-command-description:: show

Usage
*****

.. pip-command-usage:: show

Options
*******

.. pip-command-options:: show
